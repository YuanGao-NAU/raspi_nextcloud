import './systemtags.js'
import './templates.js'
import './systemtagmodel.js'
import './systemtagsmappingcollection.js'
import './systemtagscollection.js'
import './systemtagsinputfield.js'

import '../../css/systemtags.scss'
